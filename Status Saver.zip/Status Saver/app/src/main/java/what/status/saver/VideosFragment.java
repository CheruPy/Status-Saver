package what.status.saver;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideosFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<StatusModel> videoList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_videos, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewVideos);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        loadVideos();
        return view;
    }

    private void loadVideos() {
        videoList.clear();
        String[] paths = {
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"
        };

        for (String path : paths) {
            File directory = new File(path);
            if (directory.exists()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.getName().endsWith(".mp4")) {
                            videoList.add(new StatusModel(file.getAbsolutePath(), true));
                        }
                    }
                }
            }
        }

        if (videoList.isEmpty()) {
            Toast.makeText(getContext(), "No Videos Found", Toast.LENGTH_SHORT).show();
        }

        StatusAdapter adapter = new StatusAdapter(getContext(), videoList);
        recyclerView.setAdapter(adapter);
    }
}
