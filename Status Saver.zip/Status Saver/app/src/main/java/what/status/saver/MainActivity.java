package what.status.saver;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ✅ Toolbar setup
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Status Saver");

        toolbar.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.action_chat) {
                try {
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
                    if (intent != null) startActivity(intent);
                    else Toast.makeText(this, "WhatsApp not installed", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Error opening WhatsApp", Toast.LENGTH_SHORT).show();
                }
                return true;

            } else if (id == R.id.action_notifications) {
                Toast.makeText(this, "Notifications Clicked", Toast.LENGTH_SHORT).show();
                return true;

            } else if (id == R.id.action_share) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Status Saver");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "Hey! Try this Status Saver app to save WhatsApp statuses.");
                startActivity(Intent.createChooser(shareIntent, "Share via"));
                return true;
            }

            return false;
        });

        // ✅ Tabs + ViewPager
        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);

        ViewPagerAdapter adapter = new ViewPagerAdapter(this);
        adapter.addFragment(new ImagesFragment());
        adapter.addFragment(new VideosFragment());
        viewPager.setAdapter(adapter);

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            if (position == 0) tab.setText("IMAGES");
            else tab.setText("VIDEOS");
        }).attach();

        // ✅ Bottom Navigation
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_status) {
                Toast.makeText(this, "Status Page", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.nav_bstatus) {
                Toast.makeText(this, "Business Status Page", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.nav_saved) {
                Toast.makeText(this, "Saved Page", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.nav_settings) {
                Toast.makeText(this, "Settings Page", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
    }
}
