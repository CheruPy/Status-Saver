package what.status.saver;


import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

public class StatusAdapter extends RecyclerView.Adapter<StatusAdapter.ViewHolder> {
    private Context context;
    private List<StatusModel> statusList;

    public StatusAdapter(Context context, List<StatusModel> statusList) {
        this.context = context;
        this.statusList = statusList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_status, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StatusModel model = statusList.get(position);

        // Load image/video thumbnail
        Glide.with(context).load(model.getPath()).into(holder.imageView);

        // ✅ Save button
        holder.btnDownload.setOnClickListener(v -> {
            try {
                File src = new File(model.getPath());
                File dest = new File(Environment.getExternalStorageDirectory() + "/StatusSaver/");
                if (!dest.exists()) dest.mkdirs();

                File file = new File(dest, src.getName());
                FileInputStream in = new FileInputStream(src);
                FileOutputStream out = new FileOutputStream(file);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
                in.close();
                out.close();

                // ✅ Notify Gallery
                MediaScannerConnection.scanFile(context,
                        new String[]{file.getAbsolutePath()},
                        null,
                        (path, uri) -> {});

                Toast.makeText(context, "Saved to Gallery!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "Error saving file", Toast.LENGTH_SHORT).show();
            }
        });

        // ✅ Share button
        holder.btnShare.setOnClickListener(v -> {
            try {
                File file = new File(model.getPath());
                Uri uri = FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", file);

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);

                if (model.isVideo()) {
                    shareIntent.setType("video/*");
                } else {
                    shareIntent.setType("image/*");
                }

                context.startActivity(Intent.createChooser(shareIntent, "Share Status via"));
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "Error sharing file", Toast.LENGTH_SHORT).show();
            }
        });

// ✅ Repost button (direct to WhatsApp)
        holder.btnRepost.setOnClickListener(v -> {
            try {
                File file = new File(model.getPath());
                Uri uri = FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", file);

                Intent repostIntent = new Intent(Intent.ACTION_SEND);
                repostIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                repostIntent.putExtra(Intent.EXTRA_STREAM, uri);

                if (model.isVideo()) {
                    repostIntent.setType("video/*");
                } else {
                    repostIntent.setType("image/*");
                }

                repostIntent.setPackage("com.whatsapp");
                context.startActivity(repostIntent);

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return statusList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        Button btnDownload, btnShare, btnRepost;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            btnDownload = itemView.findViewById(R.id.btnDownload);
            btnShare = itemView.findViewById(R.id.btnShare);
            btnRepost = itemView.findViewById(R.id.btnRepost);
        }
    }
}
