package what.status.saver;

import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class PreviewActivity extends AppCompatActivity {

    private ImageView imageView;
    private VideoView videoView;
    private Button btnDownload, btnShare, btnRepost;

    private String filePath;
    private boolean isVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        imageView = findViewById(R.id.previewImage);
        videoView = findViewById(R.id.previewVideo);
        btnDownload = findViewById(R.id.btnDownload);
        btnShare = findViewById(R.id.btnShare);
        btnRepost = findViewById(R.id.btnRepost);

        // Get data from Intent
        filePath = getIntent().getStringExtra("filePath");
        isVideo = getIntent().getBooleanExtra("isVideo", false);

        File file = new File(filePath);

        if (isVideo) {
            imageView.setVisibility(ImageView.GONE);
            videoView.setVisibility(VideoView.VISIBLE);
            videoView.setVideoPath(file.getAbsolutePath());
            videoView.start();
        } else {
            videoView.setVisibility(VideoView.GONE);
            imageView.setVisibility(ImageView.VISIBLE);
            Glide.with(this).load(file.getAbsolutePath()).into(imageView);
        }

        // Save button
        btnDownload.setOnClickListener(v -> saveFile(file));

        // Share button
        btnShare.setOnClickListener(v -> shareFile(file));

        // Repost button
        btnRepost.setOnClickListener(v -> repostFile(file));
    }

    private void saveFile(File src) {
        try {
            File destDir = new File(Environment.getExternalStorageDirectory() + "/StatusSaver/");
            if (!destDir.exists()) destDir.mkdirs();

            File file = new File(destDir, src.getName());
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(file);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            in.close();
            out.close();

            MediaScannerConnection.scanFile(this,
                    new String[]{file.getAbsolutePath()}, null, null);

            Toast.makeText(this, "Saved to Gallery!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving file", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", file);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.setType(isVideo ? "video/*" : "image/*");

            startActivity(Intent.createChooser(shareIntent, "Share via"));
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error sharing file", Toast.LENGTH_SHORT).show();
        }
    }

    private void repostFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", file);

            Intent repostIntent = new Intent(Intent.ACTION_SEND);
            repostIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            repostIntent.putExtra(Intent.EXTRA_STREAM, uri);
            repostIntent.setType(isVideo ? "video/*" : "image/*");
            repostIntent.setPackage("com.whatsapp");

            startActivity(repostIntent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "WhatsApp not installed", Toast.LENGTH_SHORT).show();
        }
    }
}
