package what.status.saver;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ImagesFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<StatusModel> imageList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_images, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewImages);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        loadImages();
        return view;
    }

    private void loadImages() {
        imageList.clear();
        String[] paths = {
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"
        };

        for (String path : paths) {
            File directory = new File(path);
            if (directory.exists()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.getName().endsWith(".jpg") || file.getName().endsWith(".png")) {
                            imageList.add(new StatusModel(file.getAbsolutePath(), false));
                        }
                    }
                }
            }
        }

        if (imageList.isEmpty()) {
            Toast.makeText(getContext(), "No Images Found", Toast.LENGTH_SHORT).show();
        }

        StatusAdapter adapter = new StatusAdapter(getContext(), imageList);
        recyclerView.setAdapter(adapter);
    }
}
